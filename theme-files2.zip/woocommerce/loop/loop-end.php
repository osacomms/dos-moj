<?php
/**
 * Product Loop End
 *
 * @version     2.0.0
 */
global $woocommerce_loop;

$woocommerce_loop['product_loop'] = '';
$woocommerce_loop['cat_loop'] = '';
$woocommerce_loop['view'] = '';
$woocommerce_loop['category-view'] = '';
$woocommerce_loop['columns'] = '';
$woocommerce_loop['column_width'] = '';
$woocommerce_loop['pagination'] = '';
$woocommerce_loop['navigation'] = '';
$woocommerce_loop['addlinks_pos'] = '';
$woocommerce_loop['widget'] = '';
?>
</ul>